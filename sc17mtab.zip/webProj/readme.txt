URL: http://sc17mtab02.pythonanywhere.com/



Username: ammar
Password: tommorrowasplanned


Name of agency: Matt Barrs



Possible Routes:
	admin/
	loginRequired
	api/login/
	api/logout/
	api/poststory/
	api/getstories/
	api/deletestory/